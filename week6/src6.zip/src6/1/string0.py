# get_string and print, with concatenation

from cs50 import get_string

s = get_string("What's your name?\n")
print("hello, " + s)
