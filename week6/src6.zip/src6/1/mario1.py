# Prints a row of 4 question marks without a loop

print("?" * 4)
