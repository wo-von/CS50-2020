# Logical operators, using lists

from cs50 import get_string

# Prompt user to agree
s = get_string("Do you agree?\n")

# Check whether agreed
if s.lower() in ["y", "yes"]:
    print("Agreed.")
elif s.lower() in ["n", "no"]:
    print("Not agreed.")
