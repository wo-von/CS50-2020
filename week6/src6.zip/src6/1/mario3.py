# Prints a column of 3 bricks without a loop

print("#\n" * 3, end="")
