# Abstraction with parameterization


def main():
    cough(3)


# Cough some number of times
def cough(n):
    for i in range(n):
        print("cough")


main()
