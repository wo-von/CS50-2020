# Opportunity for better design

print("cough")
print("cough")
print("cough")
