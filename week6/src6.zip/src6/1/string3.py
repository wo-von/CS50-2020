# input and print, with format strings

s = input("What's your name?\n")
print(f"hello, {s}")
