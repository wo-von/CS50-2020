# get_int and print

from cs50 import get_int

age = get_int("What's your age?\n")
print(f"You are at least {age * 365} days old.")
